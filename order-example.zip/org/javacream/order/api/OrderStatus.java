package org.javacream.order.api;

public enum OrderStatus {
	OK, PENDING, UNAVAILABLE;
}
